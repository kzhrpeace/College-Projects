#include "stack.h"

struct double_stack * double_stack_new(int max_size) {
}

// push a value onto the stack
void double_stack_push(struct double_stack * this, double value) {
}

// pop a value from the stack
double double_stack_pop(struct double_stack * this) {
}
